/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.programmingproject;

/**
 * This is a class called "Cash" that extends the "Payment" class.
 * @author fatom
 */
public class Cash extends Payment{
    
    

    // Constructor
    public Cash() {
     /*  It calls the constructor of the superclass "Payment"
           with the string "cash" as a parameter.
         */    
        super("cash");
    }
    

    
}