/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.programmingproject;

/**
 *
 * @author fatom
 */
import java.util.ArrayList;



public class Menu {

  // Create a three ArrayList type Meal 
 private static ArrayList <Meal> breakfast= new ArrayList<Meal> ();
 private static ArrayList <Meal> lunch= new ArrayList<Meal> ();
 private static ArrayList <Meal> dinner= new ArrayList <Meal>();
 //create constructor
 public Menu(){
     
 }
 //Define method that take parameter type Menu and add element to ArrayList
public static void addElement(Menu m){
    m.breakfast.add(new Meal("PanCake combo","Two pancakes sorved with two eggs,skillet potatoes,and 3 sausage",19.67));
    m.breakfast.add(new Meal("French Toast combo","Two pieces of french toast sorved with two eggs,skillet potatoes,and 3 sausage",22.50));
    m.breakfast.add(new Meal("waffle combo","Two pieces of waffle sorved with two eggs,skillet potatoes,and 3 sausage",20.40));
    
    m.lunch.add(new Meal("Chicken pasta","made with pasta,chicken,cheese,and garlic",26.60));
    m.lunch.add(new Meal("Fish","Served with rice",27.90));
    m.lunch.add(new Meal("Pizza","served with rice",22.50));

    m.dinner.add(new Meal("Burger","served with frise",18.33));
    m.dinner.add(new Meal("Pizza","served with Onion Rings",22.50));
    m.dinner.add(new Meal("Tuna sandwich","served with green salads",17.09));
    

}

  //Define method that take parameter type String and display menu and return ArrayList     
public ArrayList<Meal> displayMenu(String meal){
   ArrayList <Meal> choose= new ArrayList<Meal> ();
      
  if(meal.equalsIgnoreCase("breakfast")){
      for(int i=0;i<breakfast.size();i++){
      System.out.println(i+1 +": "+ breakfast.get(i));
      }
     choose.addAll(breakfast);
      
  } else if(meal.equalsIgnoreCase("lunch")){
         for(int i=0;i<lunch.size();i++){
      System.out.println(i+1 +": "+lunch.get(i));
      }
         choose.addAll(lunch);
       
  }else if(meal.equalsIgnoreCase("dinner")){
        for(int i=0;i<dinner.size();i++){
      System.out.println(i+1 +": "+ dinner.get(i));
     
        }
       choose.addAll(dinner);
  }
     return choose;
     
}

//Define method that take parameter ArrayList type Meal and int and display user order price and return Double
 public Double displayOrderPrice(int ordernum,ArrayList<Meal> choose){
     Double price = null  ;
     switch(ordernum){
         case 1:
            
             price= choose.get(0).getPrice();
           
           break;
         case 2:
             
               price= choose.get(1).getPrice();
           
             break;
         case 3:
             
                price= choose.get(2).getPrice();
                    
                    break;
                    
     }
     return price;
     
    
 
   
     
 }
 //Define method that take parameter ArrayList type Meal and int and display user order price and return the order
  public void displayOrder(int ordernum,ArrayList<Meal> choose){
       
     switch(ordernum){
         case 1 -> System.out.println( choose.get(0));
         case 2 -> System.out.println( choose.get(1));
         case 3 -> System.out.println( choose.get(2));
                    
     }
  }
   //Define method that take parameter type int and type String to retun the meal obj that the user choose
   public Meal meal(int num, String mealtype){
    Meal meal = null;
   
    if(mealtype.equalsIgnoreCase("breakfast")){
     meal = breakfast.get(num-1);
      
  }else if(mealtype.equalsIgnoreCase("lunch")){
        
      meal = lunch.get(num-1);
     
       
  }else if(mealtype.equalsIgnoreCase("dinner")){
      
        meal = dinner.get(num-1);
     
        }
   return meal;
   
   }
 
   
     
 
 


    
  
}