/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.programmingproject;

/**
 *
 * @author fatom
 */
public class Meal{
 //Declare variables type string and double   
private String name;
private String description;
private double price;

//create constructor take three parameters type string and double 
 //assign value to name and description and price
public  Meal(String name, String descrip, double num){
this.name = name;
description = descrip;
price = num;
}


   //Define method that return the value of price
    public double getPrice() {
        return price;
    }


//return String object containing name and description and price
  public String toString(){
      
     

    return name+", "+description+", "+ price +" SAR";
      
     

  }

  
}