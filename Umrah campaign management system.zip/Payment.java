/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.programmingproject;
/**
 * Define the Payment class with a private paymentType field
 * @author fatom
 */
public class Payment {

  
   private String paymentType;
   
 // Define a constructor for Payment that takes a payment type parameter  
   public Payment(String type) {
       paymentType = type;
   }
 // Define a default constructor for Payment  
   public Payment(){}

// Define a method that returns the paymentType   
   public String getPaymentType(){
       return paymentType;
   }
   

// Define a method that takes a String parameter and prints a message based on the value of the parameter
public void completion(String an){

 if (an.equalsIgnoreCase("no"))
       {System.out.println("Payment failed");}
 
 else if (an.equalsIgnoreCase("yes"))
         {System.out.println("Payment completed");}

 else{System.out.println("Payment failed");}
}

// Define a method that creates a deep copy of a Payment object
public Payment copy(){
     // Create a new Payment object
   Payment p = new Payment();
    // Assign the paymentType of the new Payment object to the paymentType of the original Payment object
   p.paymentType =  paymentType;
   // Return the new Payment object
       return p;
   }
}