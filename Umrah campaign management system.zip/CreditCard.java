/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.programmingproject;

/**
 *
 * @author fatom
 */
public class CreditCard extends Payment{
// The class has five private fields:
    private String name;//representing the name on the credit card
    private String type;//representing the type of credit card, e.g. Visa or Mastercard
    private String expDate;//representing the credit card number    
    private int cardNum;//representing the credit card number
    private int CvcCode;//(representing the security code on the credit card
    
    
 /*
     The class has a constructor with five parameters:
    the name on the credit card, the type of credit card,
    the expiration date of the credit card,
    the credit card number, and the security code on the credit card.
    */   
   public CreditCard(String na, String ty, String ed, int cn, int cvv){
   
     /*It calls the constructor of the superclass "Payment"
     with the string "credit card" as a parameter.
    */
   super("credit card");
    
   /*
   It initializes the private fields "name", "type", "expDate", "cardNum"
   , and "CvcCode" with the corresponding values passed as parameters.
      */    
   name = na;
   type = ty;
   expDate = ed;
   cardNum = cn;
   CvcCode = cvv;
    }

   
}