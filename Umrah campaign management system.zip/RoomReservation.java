/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.programmingproject;

import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
/**
 *
 * @author fatom
 */
public class RoomReservation{

private final int price = 300;

// Used to get the price
    public int getPrice() {
        return price;
    }
    

// Used to get dateFrom
public String dateFrom(int d,int m,int y){

return d + "/" + m + "/" + y ;
}

// Used to get dateTo
public String dateTo(int d,int m,int y){

return d + "/" + m + "/" + y;
}
    
 
   //used to display if the room is empty or not
   public void roomNum(int num) {
      
       
           if(!checkRoomNum(num)){
           
            System.out.println("room " + num + " is impty");
           
           }else{
           
           System.out.println("room " + num + " is occupied");
               
           }
           
   }

   
   
   //used to check if the room is empty or not
   public boolean checkRoomNum(int num) {
       
       String roomsReservation = "rooms.txt";  
       Scanner inStream = null;
       boolean roomEm = false;
       try{
       
       inStream = new Scanner(new File(roomsReservation));
       
       }catch(FileNotFoundException f){
       
           System.out.println("error opening file rooms");
           
           System.exit(0);
       
       }
       
       while(inStream.hasNextInt()){
       
           
         int fileint =  inStream.nextInt();   
           if(num == fileint){
           
            roomEm = true;
            break; 
            
           }else if (!(num == fileint)){
           
           roomEm = false;
             
           }
        }
       
       return roomEm;
       
        }
// Used to get the room number
   public int retunRomNum(int num) {
      
      
            return num;
           
            
   }


}