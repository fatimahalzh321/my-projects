/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.programmingproject;

/**
 *
 * @author fatom
 */
public class UserInformation {
//Declare variables type int 
  private int age;
  private int nume;
//Declare variables type string
  private String name;
  private String Passport;
  private String health;
  
//create constructor take 4 parameters type string and one type int 
//assign value to age and name and Passport and nume and health    
public UserInformation(int ag, String nam, String pas, int num, String health){
          
    age = ag;
    name = nam;
    nume = num;
    Passport = pas;
    this.health = health;
    
    }
}