/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.project.programmingproject;

/**
 *
 * This program is designed to facilitate the booking of hotel rooms and ordering of meals for Umrah campaign.
 * It prompts the user for their information, allows them to book a room, order meals, and pay by either credit card or cash.
 * The program also writes the room booking to a file called "rooms.txt".
 

 * @author fatimah
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;


    public class ProgrammingProject{
    
     
     public static void main(String[] args){
    // Initializing variables and objects

     Scanner scr = new Scanner(System.in);
     
     PrintWriter outStream = null;
     //to holde the users answers
     String an, sr, m;
     
     // Initializing rooms file
     String roomsReservation = "rooms.txt";
     
     // Welcome message
     System.out.println("********Welcom to our program**********");
     System.out.println("you are a new user?");
     an = scr.nextLine();
     System.out.println();
     
    // Check if the user is a new user or not
     if(an.equalsIgnoreCase("Yes")){
     
    // New user sign up process
      System.out.println("**new accunt**");
      
      
      
      System.out.print("Enter your age: ");
      int age = scr.nextInt();
      System.out.println();
      
      System.out.print("Enter your name: ");
      String name = scr.next();
      System.out.println();
      
      System.out.print("Enter your Passport number: ");
      String passport = scr.next();
      System.out.println();
      
      System.out.print("Enter your phone number: ");
      int nume = scr.nextInt();
      System.out.println();
      
     System.out.print("Do you have any health essus? if Yes mention it: ");
     String health = scr.next();
     System.out.println(); 
     
      // Creating new user object
     UserInformation user= new UserInformation(age,name,passport,nume,health);
     System.out.println("Accont successfully created");
     
     
     System.out.println("Thank you for joining our Umrah campaign");
     System.out.println();
     
     // Room reservation process
     System.out.println("**Room Reservation**");
     System.out.println();
     
     RoomReservation room = new RoomReservation();
     
     // Prompting user for start and end dates of their stay
     System.out.println("Enter the start date day , month , year");
     int days= scr.nextInt();
     int months=scr.nextInt();
     int years= scr.nextInt();
     
     System.out.println("enter the end date day , month , year");
     int daye= scr.nextInt();
     int monthe= scr.nextInt();
     int yeare= scr.nextInt();
    
   
      // Prompting user to choose a room number from 1 to 20
     System.out.print("Choose a room number from 1 to 20: ");
     int roomnum=scr.nextInt();
     System.out.println();
     
     // Checking if the roomnumber is valid 
     if(roomnum>20||roomnum==0){
         System.out.println("Invalid room number"); 
         System.out.println("please try agin");
         System.out.println("");
         System.out.println("Thank you for using our Umrah campaign application");
          System.exit(0);
      }
     
     
     
     
    try{
        // Opening the "rooms.txt" file for writing
        outStream = new PrintWriter(new FileWriter(roomsReservation, true));
         
        
        
       
       
        // Checking and disblay if the chosen room number is already booked

       room.roomNum(roomnum);
       
       if(room.checkRoomNum(roomnum)){
       System.out.println("please try agin");
       System.out.println();
       System.out.println("Thank you for using our Umrah campaign application");
       System.exit(0);
       
         
       }}
    
     // Error message in case the file can't be opened
   catch(FileNotFoundException f){
       System.out.println("error opening file rooms");
       System.out.println("please try agin later");
       System.out.println();
       System.out.println("Thank you for using our Umrah campaign application");
       System.exit(0);
   }  
    // Error message in case there is an IO exception

    catch (IOException ex) {
             System.out.println("error opening file rooms");
       System.out.println("please try agin later");
       System.out.println();
       System.out.println("Thank you for using our Umrah campaign application");
       System.exit(0);
         }
  
       
        
     
       
     // bill and payment objects         
      Bill roombill = null;
      Payment roompay = null;
      
      
      
      
      System.out.print("How would you like to pay, cridet card or cash ?: ");
      m = scr.nextLine();
      an = scr.nextLine();
      
      
          
          
      
      // Prompting user to choose payment method 
      if(an.equalsIgnoreCase("cridet card")){
        
          // Credit card payment process
 
          
          
         System.out.print("enter your name: ");
         String cardname = scr.nextLine();
         System.out.println();
          
         
         System.out.print("enter the card type: ");
         String type = scr.nextLine();
         System.out.println();
         
         
         System.out.print("enter the expDate: ");
         String expDate = scr.nextLine();
         System.out.println();
         
         
         System.out.print("enter the card numeber: ");
         int cardnume = scr.nextInt();
         System.out.println();
         
         
         System.out.print("enter the cvv code: ");
         int CvcCode = scr.nextInt();
         System.out.println();
         
            // Creating credit card payment object and bill object with all information
         roompay = new CreditCard(cardname,type,expDate,cardnume,CvcCode);
         
        
         
         roombill = new Bill(roompay);
         
         System.out.println("Credit card accepted");
         
         
        
         
      }else if(an.equalsIgnoreCase("cash")){
         // Cash payment process

        roompay = new Cash();
          
        roombill = new Bill(roompay);
         System.out.println("");
         
      
      
     
      // Error message in case payment method is invalid
    }else {
          System.out.println("Invalid payment"); 
         System.out.println("please try agin");
         System.out.println("");
         System.out.println("Thank you for using our Umrah campaign application");
          System.exit(0);
          }
      
    
        
        
      // displaying bill 
      System.out.println();
      roombill.roomShowDetails();
      System.out.println();
      
      //booking confirmation from the user
      System.out.print("want to complete the payment process ?: ");
      an = scr.next();
      
      // writing room reservation to file
      if(an.equalsIgnoreCase("yes"))
               {
               outStream.println(roomnum+" is booked");
               }
        // Closing the file stream
        outStream.close();
  
        // disblay booking confirmation from the user 
         roompay.completion(an);
      
      
        
      if (roompay.getPaymentType().equalsIgnoreCase("cash") && an.equalsIgnoreCase("yes")){
           System.out.println("Your reservation start in "+ room.dateFrom(days, months, years)+" and end in " +room.dateTo(daye,monthe,yeare)+" and you room number "+room.retunRomNum(roomnum));
           System.out.println();
           System.out.println("you can pay at the reception.");
      }
      
      else if(roompay.getPaymentType().equalsIgnoreCase("credit card") && an.equalsIgnoreCase("yes")){
         System.out.println("Your reservation start in "+ room.dateFrom(days, months, years)+" and end in " +room.dateTo(daye,monthe,yeare)+" and you room number "+room.retunRomNum(roomnum));
           System.out.println();
           System.out.println("the amount will be withdrawn from your bank accunt.");
      }
     System.out.println();
     
       
       
       
   
     
      
     }else if(an.equalsIgnoreCase("no")){
  
         
         
         
      // Meal ordering process    
      System.out.println("***Meal ordering***");
      System.out.print("breakfast, lunch or dinner: ");
      
      
    //choosing breakfast, lunch or dinner 
     // Reading user input
      String mealtype = scr.next();
      System.out.println();
      
    //error masage if the input nut from the given types  
      if(!(mealtype.equalsIgnoreCase("breakfast"))&&!(mealtype.equalsIgnoreCase("lunch"))&&!(mealtype.equalsIgnoreCase("dinner"))){
         System.out.println("Invalid meal type"); 
         System.out.println("please try agin");
         System.out.println("");
         System.out.println("Thank you for using our Umrah campaign application");
         System.exit(0);
          }
     
     
    // Display menu and prompt user to choose meal number  
       ArrayList<Meal> choose;
    
       Menu order = new Menu();
       
       Menu.addElement(order);
       
       choose=order.displayMenu(mealtype);
       System.out.println();
       
       System.out.print("Choose meal number you want: ");
     
      
       int num=scr.nextInt();
       System.out.println();
    // Validate meal number input   
       if(num>3){System.out.println("Invalid meal number"); 
         System.out.println("please try agin");
         System.out.println("");
         System.out.println("Thank you for using our Umrah campaign application");
          System.exit(0);
          }
       
        
    // Display meal order and disblay meal 
       System.out.print("Your order is ");
       order.displayOrder(num, choose);
        System.out.println();
    
    
      
      
      
    // Prompt user to choose payment method   
      Bill bill = null;
      Payment pay = null;
      
      
      
      
      System.out.print("How would you like to pay, cridet card or cash ?: ");
      sr = scr.nextLine();
      an = scr.nextLine();
    
    // If user chooses credit card, prompt for credit card details and create CreditCard object
      if(an.equalsIgnoreCase("cridet card")){
      
          
          
          
         System.out.print("enter your name: ");
         String cardnume = scr.nextLine();
         System.out.println();
          
         
         System.out.print("enter the card type: ");
         String type = scr.nextLine();
         System.out.println();
         
         
         System.out.print("enter the expDate: ");
         String expDate = scr.nextLine();
         System.out.println();
         
         
         System.out.print("enter the cardname: ");
         int cardname = scr.nextInt();
         System.out.println();
         
         
         System.out.print("enter the cvv code: ");
         int CvcCode = scr.nextInt();
         System.out.println();
         
         
         pay = new CreditCard(cardnume,type,expDate,cardname,CvcCode);
         
         bill = new Bill(order.meal(num,mealtype), pay);
         System.out.println("Credit card accepted");
         
         
        
       // If payment is by cash, create Cash object   
      }else if(an.equalsIgnoreCase("cash")){
      
        pay = new Cash();
          
        bill = new Bill(order.meal(num,mealtype), pay);
         System.out.println("");
         
      
      
     
     // Handle invalid payment option
    }else {
          System.out.println("Invalid payment"); 
         System.out.println("please try agin");
         System.out.println("");
         System.out.println("Thank you for using our Umrah campaign application");
          System.exit(0);
          }
      
    
        
        
    // Display meal details and prompt user to complete payment  
      System.out.println();
      bill.mealShowDetails();
     
      
    // Complete payment and display payment details  
      System.out.print("want to complete the payment process ?: ");
      an = scr.next();
      
      pay.completion(an);
     
      
    // If payment is by cash, display instructions to pay at reception    
      if (pay.getPaymentType().equalsIgnoreCase("cash") && an.equalsIgnoreCase("yes")){
          System.out.println("Enjoy the meal at the hotel's restaurant, you can pay at the reception.");
      }
    // If payment is by credit card, display instructions for payment withdrawal  
      else if(pay.getPaymentType().equalsIgnoreCase("credit card") && an.equalsIgnoreCase("yes")){
         System.out.println("Enjoy the meal at the hotel's restaurant, the amount will be withdrawn from your bank accunt.");
      }
     System.out.println();
     
      
      
      
      
      
     }
    // Display thank you message for using the application 
     System.out.println("Thank you for using our Umrah campaign application");
     }
    
     
}