/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.programmingproject;

/**
 *this class will display the bill to user.
 * @author fatom
 */
public class Bill {

    //The class has three private fields: 
    private Meal  meal; //which used to represents the cost of the guest's meals
    private RoomReservation room;//which used to represents the cost of the guest's room price
    private Payment paymentType;//which represents the type of payment.

    //constructor take a meal obj and the payment type 
    public Bill(Meal meals, Payment payment) {
       meal = meals;
       /*It initializes the "paymentType" field with
         a copy of the "Payment" object passed as
         a parameter using the "copy" method.        
       */ 
       paymentType = payment.copy();
    }
    
    //constructor taake the payment type and make a RoomReservation obj
     public Bill(Payment payment) {
      /*It initializes the "paymentType" field with
         a copy of the "Payment" object passed as
         a parameter using the "copy" method.        
       */ 
       paymentType = payment.copy();
       
       room = new RoomReservation();
     }
   
   
//method to display the meal bill
    public void mealShowDetails() {
        System.out.println("-- Your Meal Bill --");
         //print the meal cost 
        System.out.println("Meal Cost: " + meal.getPrice());

        System.out.println("-------------------------------------");
    }
    
     //method to display the room cost 
    public void roomShowDetails() {
        
     System.out.println("-- Your Reservation Bill --");   
     /*
      It creates a new integer variable called "roomCost" 
     and assigns it the value returned by calling the "getRoomPrice" method.
     */    
        int roomCost = getRoomPrice();
        System.out.println("Room Cost:" + roomCost);
        
    }
    
    //getter to return room price
   public int getRoomPrice(){
       return room.getPrice();
   }
   
    

}